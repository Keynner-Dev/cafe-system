import { useState, useEffect } from 'react';
import { getCajas, getCajasDestino, getMovimientos, cerrarCaja, abrirCaja, createTraslado } from '../../api/caja';
import { useAuth } from '../../context/AuthContext';
import MovimientoModal from '../../components/caja/MovimientoModal';

const IconPlus = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
    <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
  </svg>
);
const IconCaja = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <rect x="2" y="7" width="20" height="14" rx="2" />
    <path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2" />
    <line x1="12" y1="12" x2="12" y2="16" />
    <line x1="10" y1="14" x2="14" y2="14" />
  </svg>
);
const IconLock = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
    <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
  </svg>
);
const IconUnlock = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
    <path d="M7 11V7a5 5 0 0 1 9.9-1"/>
  </svg>
);
const IconTransfer = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M5 12h14"/><path d="M12 5l7 7-7 7"/>
  </svg>
);
const IconX = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
    <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
  </svg>
);

function formatCOP(valor) {
  return new Intl.NumberFormat('es-CO', {
    style: 'currency', currency: 'COP', minimumFractionDigits: 0,
  }).format(valor);
}
function formatFecha(fecha) {
  return new Date(fecha).toLocaleString('es-CO', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}

// ── Modal cierre ─────────────────────────────────────────────────────────────
function CierreModal({ caja, onCerrar, onConfirmar }) {
  const [saldoFisico, setSaldoFisico] = useState('');
  const [nota, setNota]               = useState('');
  const [loading, setLoading]         = useState(false);
  const [error, setError]             = useState(null);

  const saldoTeorico = Number(caja.saldo_actual);
  const diferencia   = saldoFisico !== '' ? Number(saldoFisico) - saldoTeorico : null;

  const handleSubmit = async () => {
    if (saldoFisico === '') { setError('Debes ingresar el efectivo contado.'); return; }
    setLoading(true); setError(null);
    try {
      await cerrarCaja(caja.id, { saldo_fisico: Number(saldoFisico), nota });
      onConfirmar();
    } catch (e) {
      setError(e.response?.data?.detail || 'Error al cerrar la caja.');
    } finally { setLoading(false); }
  };

  return (
    <div onClick={e => { if (e.target === e.currentTarget) onCerrar(); }}
      style={{ position: 'fixed', inset: 0, background: 'rgba(15,23,42,0.5)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 60, padding: 16 }}>
      <div style={{ background: 'white', borderRadius: 12, width: '100%', maxWidth: 420,
        boxShadow: '0 20px 60px rgba(0,0,0,0.15)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          padding: '18px 20px', borderBottom: '1px solid #f1f5f9' }}>
          <div>
            <h2 style={{ fontSize: 15, fontWeight: 600, color: '#0f172a', margin: 0 }}>Cerrar caja</h2>
            <p style={{ color: '#94a3b8', fontSize: 12, marginTop: 2 }}>{caja.bodega_nombre}</p>
          </div>
          <button onClick={onCerrar} style={{ width: 30, height: 30, borderRadius: 6, border: 'none',
            background: 'transparent', cursor: 'pointer', color: '#94a3b8',
            display: 'flex', alignItems: 'center', justifyContent: 'center' }}><IconX /></button>
        </div>
        <div style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 16 }}>
          {error && <div style={{ background: '#fef2f2', border: '1px solid #fecaca',
            borderRadius: 6, padding: '10px 12px', color: '#dc2626', fontSize: 12 }}>{error}</div>}
          <div style={{ background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 8, padding: '14px 16px' }}>
            <p style={{ fontSize: 12, color: '#64748b', margin: 0 }}>Saldo teórico en sistema</p>
            <p style={{ fontSize: 24, fontWeight: 700, color: '#0f172a', margin: '4px 0 0' }}>
              {formatCOP(saldoTeorico)}</p>
          </div>
          <div>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: '#475569', marginBottom: 5 }}>
              Efectivo físico contado *</label>
            <input type="number" value={saldoFisico} onChange={e => setSaldoFisico(e.target.value)}
              placeholder="0" min="0" autoFocus
              style={{ width: '100%', boxSizing: 'border-box', border: '1px solid #e2e8f0',
                borderRadius: 6, padding: '9px 12px', fontSize: 16, color: '#0f172a',
                outline: 'none', background: 'white', fontWeight: 600 }}
              onFocus={e => e.target.style.borderColor = '#16a34a'}
              onBlur={e => e.target.style.borderColor = '#e2e8f0'} />
          </div>
          {diferencia !== null && (
            <div style={{ background: diferencia === 0 ? '#f0fdf4' : diferencia > 0 ? '#eff6ff' : '#fef2f2',
              border: `1px solid ${diferencia === 0 ? '#bbf7d0' : diferencia > 0 ? '#bfdbfe' : '#fecaca'}`,
              borderRadius: 8, padding: '12px 16px',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 13, color: '#475569' }}>Diferencia</span>
              <span style={{ fontSize: 16, fontWeight: 700,
                color: diferencia === 0 ? '#16a34a' : diferencia > 0 ? '#2563eb' : '#dc2626' }}>
                {diferencia > 0 ? '+' : ''}{formatCOP(diferencia)}</span>
            </div>
          )}
          <div>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: '#475569', marginBottom: 5 }}>
              Nota (opcional)</label>
            <textarea value={nota} onChange={e => setNota(e.target.value)} rows={2}
              placeholder="Observación sobre el cierre..."
              style={{ width: '100%', boxSizing: 'border-box', border: '1px solid #e2e8f0',
                borderRadius: 6, padding: '8px 12px', fontSize: 13, color: '#0f172a',
                outline: 'none', background: 'white', resize: 'vertical' }}
              onFocus={e => e.target.style.borderColor = '#16a34a'}
              onBlur={e => e.target.style.borderColor = '#e2e8f0'} />
          </div>
        </div>
        <div style={{ display: 'flex', gap: 10, padding: '0 20px 20px' }}>
          <button onClick={onCerrar} style={{ flex: 1, padding: 9, border: '1px solid #e2e8f0',
            borderRadius: 6, background: 'white', color: '#475569', fontSize: 13,
            fontWeight: 500, cursor: 'pointer' }}>Cancelar</button>
          <button onClick={handleSubmit} disabled={loading}
            style={{ flex: 1, padding: 9, border: 'none', borderRadius: 6,
              background: loading ? '#94a3b8' : '#0f172a', color: 'white',
              fontSize: 13, fontWeight: 600, cursor: loading ? 'not-allowed' : 'pointer' }}>
            {loading ? 'Cerrando...' : 'Confirmar cierre'}</button>
        </div>
      </div>
    </div>
  );
}

// ── Modal traslado de dinero ──────────────────────────────────────────────────
// `cajas`: lista para poblar destino (jefe → todas con saldo; admin → cajasDestino sin saldo)
// `cajaOrigen`: objeto COMPLETO de la caja propia del admin (con saldo real), o null si es jefe
function TrasladoModal({ cajas, cajaOrigen, onCerrar, onConfirmar }) {
  const cajasDestino = cajas.filter(c => c.id !== cajaOrigen?.id);

  const [form, setForm] = useState({
    caja_origen:  cajaOrigen?.id || '',
    caja_destino: cajasDestino[0]?.id || '',
    valor: '',
    nota: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState(null);

  // Si hay cajaOrigen fijo (admin), el saldo real viene de ahí (dato propio, sí permitido).
  // Si es jefe, busca el saldo en la lista `cajas` (que sí trae saldo_actual completo).
  const cajaOrigenActual = cajaOrigen || cajas.find(c => c.id === Number(form.caja_origen));
  const saldoDisponible  = Number(cajaOrigenActual?.saldo_actual || 0);

  const handleSubmit = async () => {
    if (!form.valor || Number(form.valor) <= 0) {
      setError('El valor debe ser mayor a cero.'); return;
    }
    if (Number(form.valor) > saldoDisponible) {
      setError(`Saldo insuficiente. Disponible: ${formatCOP(saldoDisponible)}`); return;
    }
    if (!form.caja_destino) { setError('Selecciona una caja destino.'); return; }

    setLoading(true); setError(null);
    try {
      await createTraslado({
        caja_origen:  Number(form.caja_origen),
        caja_destino: Number(form.caja_destino),
        valor: Number(form.valor),
        nota: form.nota,
      });
      onConfirmar();
    } catch (e) {
      setError(e.response?.data?.detail || JSON.stringify(e.response?.data) || 'Error al trasladar.');
    } finally { setLoading(false); }
  };

  const inputStyle = {
    width: '100%', boxSizing: 'border-box', border: '1px solid #e2e8f0',
    borderRadius: 6, padding: '9px 12px', fontSize: 13, color: '#0f172a',
    outline: 'none', background: 'white',
  };

  return (
    <div onClick={e => { if (e.target === e.currentTarget) onCerrar(); }}
      style={{ position: 'fixed', inset: 0, background: 'rgba(15,23,42,0.5)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 60, padding: 16 }}>
      <div style={{ background: 'white', borderRadius: 12, width: '100%', maxWidth: 440,
        boxShadow: '0 20px 60px rgba(0,0,0,0.15)' }}>

        {/* Cabecera */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          padding: '18px 20px', borderBottom: '1px solid #f1f5f9' }}>
          <div>
            <h2 style={{ fontSize: 15, fontWeight: 600, color: '#0f172a', margin: 0 }}>
              Trasladar dinero</h2>
            <p style={{ color: '#94a3b8', fontSize: 12, marginTop: 2 }}>
              Entre cajas de diferentes bodegas</p>
          </div>
          <button onClick={onCerrar} style={{ width: 30, height: 30, borderRadius: 6, border: 'none',
            background: 'transparent', cursor: 'pointer', color: '#94a3b8',
            display: 'flex', alignItems: 'center', justifyContent: 'center' }}><IconX /></button>
        </div>

        <div style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 14 }}>
          {error && <div style={{ background: '#fef2f2', border: '1px solid #fecaca',
            borderRadius: 6, padding: '10px 12px', color: '#dc2626', fontSize: 12 }}>{error}</div>}

          {/* Origen */}
          <div>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: '#475569', marginBottom: 5 }}>
              Caja origen</label>
            <select value={form.caja_origen}
              onChange={e => setForm(p => ({ ...p, caja_origen: e.target.value, caja_destino: '' }))}
              disabled={!!cajaOrigen}
              style={{ ...inputStyle, background: cajaOrigen ? '#f8fafc' : 'white' }}
              onFocus={e => e.target.style.borderColor = '#16a34a'}
              onBlur={e => e.target.style.borderColor = '#e2e8f0'}>
              {cajaOrigen ? (
                // Admin: caja fija, con su saldo real (dato propio permitido)
                <option value={cajaOrigen.id}>
                  {cajaOrigen.bodega_nombre} — {formatCOP(cajaOrigen.saldo_actual)}
                </option>
              ) : (
                // Jefe: puede elegir cualquier caja como origen, todas con saldo
                cajas.map(c => (
                  <option key={c.id} value={c.id}>{c.bodega_nombre} — {formatCOP(c.saldo_actual)}</option>
                ))
              )}
            </select>
            {cajaOrigenActual && (
              <p style={{ fontSize: 11, color: '#64748b', marginTop: 4 }}>
                Saldo disponible: <strong>{formatCOP(saldoDisponible)}</strong>
              </p>
            )}
          </div>

          {/* Flecha */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#16a34a' }}>
            <IconTransfer />
          </div>

          {/* Destino — nunca muestra saldo, ya sea lista de jefe o de admin */}
          <div>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: '#475569', marginBottom: 5 }}>
              Caja destino</label>
            <select value={form.caja_destino}
              onChange={e => setForm(p => ({ ...p, caja_destino: e.target.value }))}
              style={inputStyle}
              onFocus={e => e.target.style.borderColor = '#16a34a'}
              onBlur={e => e.target.style.borderColor = '#e2e8f0'}>
              <option value="">Selecciona una caja</option>
              {cajas.filter(c => c.id !== Number(form.caja_origen)).map(c => (
                <option key={c.id} value={c.id}>{c.bodega_nombre}</option>
              ))}
            </select>
          </div>

          {/* Valor */}
          <div>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: '#475569', marginBottom: 5 }}>
              Valor a trasladar *</label>
            <input type="number" value={form.valor}
              onChange={e => setForm(p => ({ ...p, valor: e.target.value }))}
              placeholder="0" min="1" autoFocus
              style={{ ...inputStyle, fontSize: 15, fontWeight: 600 }}
              onFocus={e => e.target.style.borderColor = '#16a34a'}
              onBlur={e => e.target.style.borderColor = '#e2e8f0'} />
          </div>

          {/* Nota */}
          <div>
            <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: '#475569', marginBottom: 5 }}>
              Nota (opcional)</label>
            <textarea value={form.nota} onChange={e => setForm(p => ({ ...p, nota: e.target.value }))}
              rows={2} placeholder="Motivo del traslado..."
              style={{ ...inputStyle, resize: 'vertical' }}
              onFocus={e => e.target.style.borderColor = '#16a34a'}
              onBlur={e => e.target.style.borderColor = '#e2e8f0'} />
          </div>
        </div>

        <div style={{ display: 'flex', gap: 10, padding: '0 20px 20px' }}>
          <button onClick={onCerrar} style={{ flex: 1, padding: 9, border: '1px solid #e2e8f0',
            borderRadius: 6, background: 'white', color: '#475569', fontSize: 13,
            fontWeight: 500, cursor: 'pointer' }}>Cancelar</button>
          <button onClick={handleSubmit} disabled={loading}
            style={{ flex: 1, padding: 9, border: 'none', borderRadius: 6,
              background: loading ? '#86efac' : '#16a34a', color: 'white',
              fontSize: 13, fontWeight: 600, cursor: loading ? 'not-allowed' : 'pointer' }}>
            {loading ? 'Trasladando...' : 'Confirmar traslado'}</button>
        </div>
      </div>
    </div>
  );
}

// ── Página principal ──────────────────────────────────────────────────────────
export default function CajaPage() {
  const { usuario } = useAuth();
  const esJefe = usuario?.rol === 'jefe';

  const [cajas,            setCajas]            = useState([]);
  const [cajasDestino,     setCajasDestino]     = useState([]); // solo se usa para admin
  const [cajaSeleccionada, setCajaSeleccionada] = useState(null);
  const [movimientos,      setMovimientos]      = useState([]);
  const [cargandoCajas,    setCargandoCajas]    = useState(true);
  const [cargandoMov,      setCargandoMov]      = useState(false);
  const [modalAbierto,     setModalAbierto]     = useState(false);
  const [modalCierre,      setModalCierre]      = useState(false);
  const [modalTraslado,    setModalTraslado]    = useState(false);
  const [filtroTipo,       setFiltroTipo]       = useState('todos');
  const [loadingAbrir,     setLoadingAbrir]     = useState(false);

  useEffect(() => {
    getCajas()
      .then(res => {
        const data = res.data;
        setCajas(data);
        if (!esJefe && data.length > 0) setCajaSeleccionada(data[0]);
      })
      .finally(() => setCargandoCajas(false));

    // El admin solo recibe su propia caja en getCajas(), así que necesita
    // esta lista aparte (sin saldo) para saber a qué otras cajas puede trasladar.
    if (!esJefe) {
      getCajasDestino().then(res => setCajasDestino(res.data));
    }
  }, []);

  useEffect(() => {
    if (!cajaSeleccionada) return;
    setCargandoMov(true);
    getMovimientos(cajaSeleccionada.id)
      .then(res => setMovimientos(res.data))
      .finally(() => setCargandoMov(false));
  }, [cajaSeleccionada]);

  const refrescar = () => {
    getCajas().then(res => {
      setCajas(res.data);
      if (cajaSeleccionada) {
        const actualizada = res.data.find(c => c.id === cajaSeleccionada.id);
        if (actualizada) setCajaSeleccionada(actualizada);
      }
    });
    if (cajaSeleccionada) {
      getMovimientos(cajaSeleccionada.id).then(res => setMovimientos(res.data));
    }
  };

  const handleAbrirCaja = async (caja) => {
    setLoadingAbrir(true);
    try { await abrirCaja(caja.id); refrescar(); }
    finally { setLoadingAbrir(false); }
  };

  const totalConsolidado = cajas.reduce((acc, c) => acc + Number(c.saldo_actual), 0);
  const movimientosFiltrados = movimientos.filter(mov =>
    filtroTipo === 'todos' ? true : mov.tipo === filtroTipo
  );
  const cajaActual = cajaSeleccionada
    ? cajas.find(c => c.id === cajaSeleccionada.id) || cajaSeleccionada
    : null;
  const cajaEstaAbierta = cajaActual?.abierta !== false;

  // Jefe: usa `cajas` (todas, con saldo) para decidir si mostrar el botón.
  // Admin: usa `cajasDestino` (todas, sin saldo) porque `cajas` solo trae la suya.
  const puedeTrasladar = esJefe ? cajas.length > 1 : cajasDestino.length > 1;

  if (cargandoCajas) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '60vh' }}>
        <div style={{ width: 36, height: 36, borderRadius: '50%',
          border: '3px solid #e2e8f0', borderTopColor: '#16a34a',
          animation: 'spin 0.8s linear infinite' }} />
        <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
      </div>
    );
  }

  return (
    <div style={{ padding: '28px 32px', maxWidth: 1100, margin: '0 auto' }}>

      {/* Encabezado */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: '#0f172a', margin: 0 }}>Caja</h1>
          <p style={{ color: '#64748b', fontSize: 14, margin: '4px 0 0' }}>
            Movimientos de dinero por bodega</p>
        </div>

        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          {/* Cerrar / abrir */}
          {cajaActual && (
            cajaEstaAbierta ? (
              <button onClick={() => setModalCierre(true)}
                style={{ display: 'flex', alignItems: 'center', gap: 8,
                  background: '#0f172a', color: 'white', border: 'none',
                  borderRadius: 6, padding: '9px 16px', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}
                onMouseEnter={e => e.currentTarget.style.background = '#1e293b'}
                onMouseLeave={e => e.currentTarget.style.background = '#0f172a'}>
                <IconLock /> Cerrar caja
              </button>
            ) : (
              <button onClick={() => handleAbrirCaja(cajaActual)} disabled={loadingAbrir}
                style={{ display: 'flex', alignItems: 'center', gap: 8,
                  background: '#16a34a', color: 'white', border: 'none',
                  borderRadius: 6, padding: '9px 16px', fontSize: 13, fontWeight: 600,
                  cursor: loadingAbrir ? 'not-allowed' : 'pointer' }}>
                <IconUnlock /> {loadingAbrir ? 'Abriendo...' : 'Abrir caja'}
              </button>
            )
          )}

          {/* Trasladar dinero */}
          {puedeTrasladar && (
            <button onClick={() => setModalTraslado(true)}
              style={{ display: 'flex', alignItems: 'center', gap: 8,
                background: 'white', color: '#0f172a',
                border: '1px solid #e2e8f0', borderRadius: 6,
                padding: '9px 16px', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}
              onMouseEnter={e => e.currentTarget.style.background = '#f8fafc'}
              onMouseLeave={e => e.currentTarget.style.background = 'white'}>
              <IconTransfer /> Trasladar dinero
            </button>
          )}

          {/* Registrar movimiento */}
          {(!esJefe || cajaActual) && cajaEstaAbierta && (
            <button onClick={() => setModalAbierto(true)}
              style={{ display: 'flex', alignItems: 'center', gap: 8,
                background: '#16a34a', color: 'white', border: 'none',
                borderRadius: 6, padding: '9px 18px', fontSize: 14, fontWeight: 600, cursor: 'pointer' }}
              onMouseEnter={e => e.currentTarget.style.background = '#15803d'}
              onMouseLeave={e => e.currentTarget.style.background = '#16a34a'}>
              <IconPlus /> Registrar movimiento
            </button>
          )}
        </div>
      </div>

      {/* Banner caja cerrada */}
      {cajaActual && !cajaEstaAbierta && (
        <div style={{ background: '#fef2f2', border: '1px solid #fecaca',
          borderRadius: 10, padding: '16px 20px', marginBottom: 20,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ background: '#fee2e2', borderRadius: 8, padding: 10,
              display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#dc2626' }}>
              <IconLock />
            </div>
            <div>
              <p style={{ fontSize: 14, fontWeight: 600, color: '#dc2626', margin: 0 }}>Caja cerrada</p>
              {cajaActual.ultimo_cierre && (
                <p style={{ fontSize: 12, color: '#94a3b8', margin: '3px 0 0' }}>
                  Último cierre · saldo sistema {formatCOP(cajaActual.ultimo_cierre.saldo_teorico)}
                  {' · '}efectivo contado {formatCOP(cajaActual.ultimo_cierre.saldo_fisico)}
                  {cajaActual.ultimo_cierre.diferencia !== 0 && (
                    <span style={{
                      color: cajaActual.ultimo_cierre.diferencia > 0 ? '#2563eb' : '#dc2626',
                      fontWeight: 600, marginLeft: 4 }}>
                      ({cajaActual.ultimo_cierre.diferencia > 0 ? '+' : ''}{formatCOP(cajaActual.ultimo_cierre.diferencia)})
                    </span>
                  )}
                </p>
              )}
            </div>
          </div>
          <button onClick={() => handleAbrirCaja(cajaActual)} disabled={loadingAbrir}
            style={{ display: 'flex', alignItems: 'center', gap: 8,
              background: '#16a34a', color: 'white', border: 'none',
              borderRadius: 6, padding: '8px 16px', fontSize: 13, fontWeight: 600,
              cursor: loadingAbrir ? 'not-allowed' : 'pointer', flexShrink: 0 }}>
            <IconUnlock /> {loadingAbrir ? 'Abriendo...' : 'Abrir caja'}
          </button>
        </div>
      )}

      {/* Vista jefe */}
      {esJefe && (
        <>
          <div style={{ background: '#0f172a', borderRadius: 12, padding: '28px 32px',
            marginBottom: 24, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
              <div style={{ background: 'rgba(255,255,255,0.08)', borderRadius: 10, padding: 14,
                display: 'flex', alignItems: 'center', justifyContent: 'center' }}><IconCaja /></div>
              <div style={{ color: 'white' }}>
                <p style={{ margin: 0, fontSize: 13, color: '#94a3b8', fontWeight: 500 }}>
                  Total consolidado — todas las bodegas</p>
                <p style={{ margin: '4px 0 0', fontSize: 32, fontWeight: 700, letterSpacing: '-0.5px' }}>
                  {formatCOP(totalConsolidado)}</p>
              </div>
            </div>
            <div style={{ fontSize: 12, color: '#475569' }}>
              {cajas.length} bodega{cajas.length !== 1 ? 's' : ''}</div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))',
            gap: 14, marginBottom: 24 }}>
            {cajas.map(caja => (
              <div key={caja.id}
                onClick={() => setCajaSeleccionada(cajaSeleccionada?.id === caja.id ? null : caja)}
                style={{ background: 'white', borderRadius: 10, padding: '18px 20px',
                  border: `1px solid ${cajaSeleccionada?.id === caja.id ? '#16a34a' : '#e2e8f0'}`,
                  cursor: 'pointer', transition: 'all 0.15s',
                  boxShadow: cajaSeleccionada?.id === caja.id ? '0 0 0 2px #bbf7d0' : 'none',
                  opacity: caja.abierta ? 1 : 0.75 }}
                onMouseEnter={e => { if (cajaSeleccionada?.id !== caja.id) e.currentTarget.style.borderColor = '#94a3b8'; }}
                onMouseLeave={e => { if (cajaSeleccionada?.id !== caja.id) e.currentTarget.style.borderColor = '#e2e8f0'; }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div style={{ fontSize: 13, color: '#64748b', marginBottom: 6 }}>{caja.bodega_nombre}</div>
                  {!caja.abierta && (
                    <span style={{ fontSize: 10, fontWeight: 600, color: '#dc2626',
                      background: '#fee2e2', padding: '2px 7px', borderRadius: 99 }}>Cerrada</span>
                  )}
                </div>
                <div style={{ fontSize: 20, fontWeight: 700, color: '#0f172a' }}>
                  {formatCOP(caja.saldo_actual)}</div>
                {cajaSeleccionada?.id === caja.id && (
                  <div style={{ marginTop: 8, fontSize: 11, color: '#16a34a', fontWeight: 600 }}>
                    Viendo movimientos ↓</div>
                )}
              </div>
            ))}
          </div>
        </>
      )}

      {/* Vista administrador */}
      {!esJefe && cajaActual && (
        <div style={{ background: '#0f172a', borderRadius: 12, padding: '28px 32px',
          marginBottom: 24, display: 'flex', alignItems: 'center', gap: 20 }}>
          <div style={{ background: 'rgba(255,255,255,0.08)', borderRadius: 10, padding: 14,
            display: 'flex', alignItems: 'center', justifyContent: 'center' }}><IconCaja /></div>
          <div style={{ color: 'white' }}>
            <p style={{ margin: 0, fontSize: 13, color: '#94a3b8', fontWeight: 500 }}>
              Saldo actual — {cajaActual.bodega_nombre}
              {!cajaEstaAbierta && (
                <span style={{ marginLeft: 10, fontSize: 11, fontWeight: 600,
                  color: '#fca5a5', background: 'rgba(220,38,38,0.2)',
                  padding: '2px 8px', borderRadius: 99 }}>Cerrada</span>
              )}
            </p>
            <p style={{ margin: '4px 0 0', fontSize: 32, fontWeight: 700, letterSpacing: '-0.5px' }}>
              {formatCOP(cajaActual.saldo_actual)}</p>
          </div>
        </div>
      )}

      {/* Tabla movimientos */}
      {(!esJefe || cajaActual) && (
        <div style={{ background: 'white', borderRadius: 10, border: '1px solid #e2e8f0', overflow: 'hidden' }}>
          <div style={{ padding: '16px 20px', borderBottom: '1px solid #f1f5f9',
            display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h2 style={{ margin: 0, fontSize: 15, fontWeight: 600, color: '#0f172a' }}>
              Historial de movimientos
              {esJefe && cajaActual && (
                <span style={{ fontSize: 13, color: '#64748b', fontWeight: 400, marginLeft: 8 }}>
                  — {cajaActual.bodega_nombre}</span>
              )}
            </h2>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ display: 'flex', gap: 6 }}>
                {[
                  { value: 'todos',   label: 'Todos' },
                  { value: 'ingreso', label: 'Ingresos' },
                  { value: 'egreso',  label: 'Egresos' },
                ].map(op => (
                  <button key={op.value} onClick={() => setFiltroTipo(op.value)}
                    style={{ padding: '5px 12px', borderRadius: 20, fontSize: 12,
                      fontWeight: 600, cursor: 'pointer', border: 'none',
                      background: filtroTipo === op.value
                        ? op.value === 'ingreso' ? '#f0fdf4' : op.value === 'egreso' ? '#fef2f2' : '#0f172a'
                        : '#f1f5f9',
                      color: filtroTipo === op.value
                        ? op.value === 'ingreso' ? '#16a34a' : op.value === 'egreso' ? '#dc2626' : 'white'
                        : '#64748b' }}>
                    {op.label}
                  </button>
                ))}
              </div>
              {esJefe && cajaActual && (
                <button onClick={() => setCajaSeleccionada(null)}
                  style={{ fontSize: 12, color: '#64748b', background: 'none',
                    border: 'none', cursor: 'pointer', textDecoration: 'underline' }}>
                  Volver al consolidado</button>
              )}
            </div>
          </div>

          {cargandoMov ? (
            <div style={{ display: 'flex', justifyContent: 'center', padding: 48 }}>
              <div style={{ width: 28, height: 28, borderRadius: '50%',
                border: '3px solid #e2e8f0', borderTopColor: '#16a34a',
                animation: 'spin 0.8s linear infinite' }} />
            </div>
          ) : movimientosFiltrados.length === 0 ? (
            <div style={{ textAlign: 'center', padding: 48, color: '#94a3b8', fontSize: 14 }}>
              No hay movimientos {filtroTipo !== 'todos' ? `de tipo "${filtroTipo}"` : 'registrados aún'}
            </div>
          ) : (
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ background: '#0f172a' }}>
                  {['Fecha', 'Descripción', 'Tipo', 'Valor', 'Registrado por'].map(col => (
                    <th key={col} style={{ padding: '11px 16px', textAlign: 'left',
                      fontSize: 12, fontWeight: 600, color: '#e2e8f0',
                      textTransform: 'uppercase', letterSpacing: '0.05em' }}>{col}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {movimientosFiltrados.map((mov, i) => (
                  <tr key={mov.id}
                    style={{ background: i % 2 === 0 ? 'white' : '#f8fafc', borderBottom: '1px solid #f1f5f9' }}
                    onMouseEnter={e => e.currentTarget.style.background = '#f0fdf4'}
                    onMouseLeave={e => e.currentTarget.style.background = i % 2 === 0 ? 'white' : '#f8fafc'}>
                    <td style={{ padding: '12px 16px', fontSize: 13, color: '#64748b' }}>{formatFecha(mov.fecha)}</td>
                    <td style={{ padding: '12px 16px', fontSize: 14, color: '#0f172a' }}>{mov.descripcion}</td>
                    <td style={{ padding: '12px 16px' }}>
                      <span style={{ display: 'inline-block', padding: '3px 10px', borderRadius: 20,
                        fontSize: 12, fontWeight: 600,
                        background: mov.tipo === 'ingreso' ? '#f0fdf4' : '#fef2f2',
                        color: mov.tipo === 'ingreso' ? '#16a34a' : '#dc2626' }}>
                        {mov.tipo === 'ingreso' ? 'Ingreso' : 'Egreso'}
                      </span>
                    </td>
                    <td style={{ padding: '12px 16px', fontSize: 14, fontWeight: 600,
                      color: mov.tipo === 'ingreso' ? '#16a34a' : '#dc2626' }}>
                      {mov.tipo === 'egreso' ? '− ' : '+ '}{formatCOP(mov.valor)}
                    </td>
                    <td style={{ padding: '12px 16px', fontSize: 13, color: '#64748b' }}>
                      {mov.creado_por_nombre || '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {esJefe && !cajaActual && (
        <div style={{ textAlign: 'center', padding: '40px 0', color: '#94a3b8', fontSize: 14 }}>
          Selecciona una bodega para ver sus movimientos</div>
      )}

      {/* Modales */}
      {modalAbierto && (
        <MovimientoModal caja={cajaActual} cajas={cajas}
          onCerrar={() => setModalAbierto(false)}
          onGuardado={() => { setModalAbierto(false); refrescar(); }} />
      )}
      {modalCierre && cajaActual && (
        <CierreModal caja={cajaActual}
          onCerrar={() => setModalCierre(false)}
          onConfirmar={() => { setModalCierre(false); refrescar(); }} />
      )}
      {modalTraslado && (
        <TrasladoModal
          cajas={esJefe ? cajas : cajasDestino}
          cajaOrigen={!esJefe ? cajaActual : null}
          onCerrar={() => setModalTraslado(false)}
          onConfirmar={() => { setModalTraslado(false); refrescar(); }} />
      )}

      <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
    </div>
  );
}